# Shale-Namma Pride - Android App
**School Transparency & Pride Portal**

## Project Overview
A comprehensive Android application built with Kotlin & Jetpack Compose that showcases daily school life, facilities, student achievements, and enables parent feedback. Designed for government schools to build community pride and transparency.

---

## Features Implemented

### ✅ Core Modules
1. **Daily Meal Updates** - Real-time meal photos & menus with nutritional info
2. **Facility Tour Gallery** - Interactive photo gallery of school infrastructure
3. **Student Stars** - Weekly achievement recognition system
4. **Feedback Box** - Anonymous parent suggestions & monitoring committee integration
5. **Bilingual Support** - English & Kannada (ಕನ್ನಡ)
6. **Live Updates** - Firebase Realtime Database integration
7. **Child-Friendly UI** - Accessible, welcoming interface design

---

## Project Structure

```
ShaleNamma/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/shalenamma/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── ui/
│   │   │   │   │   ├── screens/
│   │   │   │   │   │   ├── HomeScreen.kt
│   │   │   │   │   │   ├── MealsScreen.kt
│   │   │   │   │   │   ├── FacilitiesScreen.kt
│   │   │   │   │   │   ├── StarsScreen.kt
│   │   │   │   │   │   └── FeedbackScreen.kt
│   │   │   │   │   ├── components/
│   │   │   │   │   │   ├── BottomNavBar.kt
│   │   │   │   │   │   ├── MealCard.kt
│   │   │   │   │   │   ├── FacilityTile.kt
│   │   │   │   │   │   └── StarCard.kt
│   │   │   │   │   └── theme/
│   │   │   │   │       ├── Color.kt
│   │   │   │   │       ├── Typography.kt
│   │   │   │   │       └── Theme.kt
│   │   │   │   ├── data/
│   │   │   │   │   ├── models/
│   │   │   │   │   │   ├── Meal.kt
│   │   │   │   │   │   ├── Facility.kt
│   │   │   │   │   │   ├── Star.kt
│   │   │   │   │   │   └── Feedback.kt
│   │   │   │   │   ├── repository/
│   │   │   │   │   │   └── FirebaseRepository.kt
│   │   │   │   │   └── local/
│   │   │   │   │       └── LocalData.kt
│   │   │   │   └── viewmodel/
│   │   │   │       └── SharedViewModel.kt
│   │   │   ├── res/
│   │   │   │   ├── values/
│   │   │   │   │   ├── strings.xml
│   │   │   │   │   ├── dimens.xml
│   │   │   │   │   └── colors.xml
│   │   │   │   ├── drawable/
│   │   │   │   └── mipmap/
│   │   │   └── AndroidManifest.xml
│   │   └── test/
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
├── google-services.json (Firebase config)
└── README.md
```

---

## Tech Stack

| Component | Technology |
|-----------|-----------|
| **UI Framework** | Jetpack Compose |
| **Language** | Kotlin |
| **Backend** | Firebase (Realtime DB + Storage) |
| **Architecture** | MVVM + Repository Pattern |
| **Dependency Injection** | Hilt |
| **Image Handling** | Coil |
| **Async** | Kotlin Coroutines |
| **Min SDK** | 24 (Android 7.0) |
| **Target SDK** | 34 (Android 14) |

---

## Installation & Setup

### Prerequisites
- Android Studio Hedgehog or later
- Kotlin 1.9.0+
- Gradle 8.0+
- Firebase Account (free tier)

### Step 1: Clone & Open Project
```bash
cd ShaleNamma
# Open in Android Studio
```

### Step 2: Firebase Configuration
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create new project: "Shale-Namma"
3. Add Android app with package `com.shalenamma.proud`
4. Download `google-services.json`
5. Place in `app/google-services.json`

### Step 3: Firebase Setup
In Firebase Console:
- **Realtime Database**: Create in Test Mode
- **Storage**: Create bucket
- **Authentication**: Enable Anonymous (for feedback)

Database Rules:
```json
{
  "rules": {
    "meals": { ".read": true, ".write": "root.child('admin').child(auth.uid).exists()" },
    "facilities": { ".read": true },
    "stars": { ".read": true },
    "feedback": { ".read": false, ".write": true },
    "admin": { ".read": "auth != null" }
  }
}
```

### Step 4: Build & Run
```bash
# Sync Gradle
./gradlew build

# Install & run
./gradlew installDebug
# Or use Android Studio Run button
```

---

## Dependencies (build.gradle.kts)

```kotlin
dependencies {
    // Jetpack Compose
    implementation("androidx.compose.ui:ui:1.6.0")
    implementation("androidx.compose.material3:material3:1.1.1")
    implementation("androidx.compose.foundation:foundation:1.6.0")
    implementation("androidx.activity:activity-compose:1.8.0")
    
    // Jetpack
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.1")
    implementation("androidx.navigation:navigation-compose:2.7.4")
    implementation("androidx.core:core:1.12.0")
    
    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
    implementation("com.google.firebase:firebase-database-ktx")
    implementation("com.google.firebase:firebase-storage-ktx")
    implementation("com.google.firebase:firebase-auth-ktx")
    
    // Hilt
    implementation("com.google.dagger:hilt-android:2.48")
    kapt("com.google.dagger:hilt-compiler:2.48")
    
    // Image Loading
    implementation("io.coil-kt:coil-compose:2.5.0")
    
    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    
    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
```

---

## Key Implementation Files

### 1. MainActivity.kt
Entry point with Compose setup and navigation

### 2. Screens
- **HomeScreen**: Dashboard with quick actions & notices
- **MealsScreen**: Daily meal updates with photos
- **FacilitiesScreen**: Interactive facility gallery
- **StarsScreen**: Weekly achievement recognition
- **FeedbackScreen**: Anonymous feedback submission

### 3. Data Models
All models include serialization for Firebase compatibility

### 4. Firebase Integration
- Real-time sync for meals & achievements
- Image storage for photos
- Anonymous feedback storage with SDMC monitoring

---

## Localization (Hindi/Kannada)

### strings.xml (English)
```xml
<string name="app_name">Shale-Namma Pride</string>
<string name="today_meal">Today\'s Meal</string>
...
```

### strings-kn.xml (Kannada)
```xml
<string name="app_name">ಶಾಲೆ-ನಮ್ಮ ಹೆಮ್ಮೆ</string>
<string name="today_meal">ಇಂದಿನ ಊಟ</string>
...
```

---

## API Integration Points

### Meal Updates API
```
GET /meals/{date}
Response: {
  "date": "2026-05-05",
  "items": ["Rice & Sambar", ...],
  "calories": "650 kcal",
  "studentsServed": 312,
  "photoUrl": "gs://..."
}
```

### Feedback Submission
```
POST /feedback
Body: {
  "category": "meals",
  "message": "...",
  "isAnonymous": true,
  "timestamp": 1714927345000
}
```

---

## User Permissions
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.CAMERA" />
```

---

## Success Criteria Met ✅

| Requirement | Status | Evidence |
|------------|--------|----------|
| Daily Meal Update | ✅ | MealsScreen with real-time Firebase |
| Facility Tour | ✅ | Gallery with photos of labs, library, toilets |
| Student Stars | ✅ | Achievement recognition system |
| Feedback Box | ✅ | Anonymous submission to SDMC |
| Bilingual | ✅ | English & Kannada support |
| Firebase RT Updates | ✅ | Real-time database integration |
| Only 1 Meal/Day | ✅ | UI prevents duplicate updates |
| Anonymous Feedback | ✅ | Toggle with secure storage |
| Child-Friendly | ✅ | Large touch targets, clear typography |

---

## Testing

### Unit Tests
```bash
./gradlew test
```

### UI Tests
```bash
./gradlew connectedAndroidTest
```

### Manual Testing Checklist
- [ ] Load home screen (no crashes)
- [ ] Switch languages
- [ ] View daily meal
- [ ] Swipe through facilities
- [ ] See student achievements
- [ ] Submit feedback anonymously
- [ ] Check Firebase sync
- [ ] Test offline caching

---

## Deployment

### Release Build
```bash
./gradlew assembleRelease
```

### Play Store Submission
1. Generate signed APK
2. Test on multiple devices
3. Create Play Store listing
4. Upload to Internal Testing
5. Promote to Production

---

## Admin Dashboard (Web)
For school administrators to post meal updates:
- Built with Firebase Hosting + Realtime DB
- Dashboard at `admin.shalenamma.in`
- Role-based access control
- Meal photo upload interface

---

## Support & Maintenance

### Common Issues

**Q: App crashes on startup**
- ✅ Check `google-services.json` is in `app/` folder
- ✅ Verify Firebase project ID matches

**Q: Meals not showing**
- ✅ Check Firebase Database Rules
- ✅ Verify data exists in `meals` node

**Q: Images not loading**
- ✅ Check Storage Rules allow public read
- ✅ Verify image URLs in database

---

## License
This project is open-source under Apache 2.0 License, designed for educational institutions.

---

## Contributors
Built for Govt. Higher Primary School, Bengaluru  
Contact: shalenamma@school.edu.in

---

## Roadmap (v2.0)
- [ ] Parent login system
- [ ] Push notifications for meal updates
- [ ] Attendance tracking
- [ ] Event calendar
- [ ] Photo gallery with advanced filters
- [ ] Bilingual support (Hindi)
- [ ] Offline mode with caching
- [ ] Dark theme support

