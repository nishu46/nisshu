import { useState, useEffect, useRef } from "react";

const COLORS = {
  saffron: "#FF6B35",
  green: "#2E8B57",
  blue: "#1565C0",
  gold: "#F4A300",
  bg: "#FFF8F0",
  card: "#FFFFFF",
  text: "#1A1A2E",
  muted: "#6B7280",
  border: "#E8E0D5",
};

const translations = {
  en: {
    appName: "Shale-Namma Pride",
    tagline: "Our School, Our Pride",
    home: "Home",
    meals: "Meals",
    facilities: "Facilities",
    stars: "Stars",
    feedback: "Feedback",
    todayMeal: "Today's Meal",
    mealDesc: "Mid-day meal served to 312 students",
    viewAll: "View All",
    facilityTour: "Facility Tour",
    facilityDesc: "Explore our labs, library & more",
    studentStars: "Student Stars",
    starsDesc: "Celebrating our achievers",
    sendFeedback: "Send Feedback",
    feedbackDesc: "Your voice matters",
    lastUpdated: "Last updated",
    menuToday: "Menu Today",
    anonymous: "Send Anonymously",
    submit: "Submit Feedback",
    placeholder: "Share your thoughts, suggestions or concerns...",
    successMsg: "Thank you! Your feedback has been received.",
    weekStar: "Student of the Week",
    sportsWinner: "Sports Champion",
    scienceStar: "Science Star",
  },
  kn: {
    appName: "ಶಾಲೆ-ನಮ್ಮ ಹೆಮ್ಮೆ",
    tagline: "ನಮ್ಮ ಶಾಲೆ, ನಮ್ಮ ಹೆಮ್ಮೆ",
    home: "ಮನೆ",
    meals: "ಊಟ",
    facilities: "ಸೌಲಭ್ಯಗಳು",
    stars: "ತಾರೆಗಳು",
    feedback: "ಪ್ರತಿಕ್ರಿಯೆ",
    todayMeal: "ಇಂದಿನ ಊಟ",
    mealDesc: "312 ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಊಟ ಬಡಿಸಲಾಯಿತು",
    viewAll: "ಎಲ್ಲಾ ನೋಡಿ",
    facilityTour: "ಸೌಲಭ್ಯ ಪ್ರವಾಸ",
    facilityDesc: "ನಮ್ಮ ಪ್ರಯೋಗಾಲಯ, ಗ್ರಂಥಾಲಯ ಅನ್ವೇಷಿಸಿ",
    studentStars: "ವಿದ್ಯಾರ್ಥಿ ತಾರೆಗಳು",
    starsDesc: "ನಮ್ಮ ಸಾಧಕರನ್ನು ಸ್ಮರಿಸುತ್ತೇವೆ",
    sendFeedback: "ಪ್ರತಿಕ್ರಿಯೆ ಕಳುಹಿಸಿ",
    feedbackDesc: "ನಿಮ್ಮ ಧ್ವನಿ ಮುಖ್ಯ",
    lastUpdated: "ಕೊನೆಯದಾಗಿ ನವೀಕರಿಸಲಾಗಿದೆ",
    menuToday: "ಇಂದಿನ ಮೆನು",
    anonymous: "ಅನಾಮಧೇಯವಾಗಿ ಕಳುಹಿಸಿ",
    submit: "ಪ್ರತಿಕ್ರಿಯೆ ಸಲ್ಲಿಸಿ",
    placeholder: "ನಿಮ್ಮ ಆಲೋಚನೆಗಳು, ಸಲಹೆಗಳು ಅಥವಾ ಕಾಳಜಿಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಿ...",
    successMsg: "ಧನ್ಯವಾದಗಳು! ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯೆ ಸ್ವೀಕರಿಸಲಾಗಿದೆ.",
    weekStar: "ವಾರದ ವಿದ್ಯಾರ್ಥಿ",
    sportsWinner: "ಕ್ರೀಡಾ ಚಾಂಪಿಯನ್",
    scienceStar: "ವಿಜ್ಞಾನ ತಾರೆ",
  },
};

const mealData = {
  date: "May 5, 2026",
  items: ["Rice & Sambar", "Vegetable Curry", "Papad", "Banana", "Buttermilk"],
  itemsKn: ["ಅನ್ನ & ಸಾಂಬಾರ್", "ತರಕಾರಿ ಕರ್ರಿ", "ಪಾಪಡ", "ಬಾಳೆಹಣ್ಣು", "ಮಜ್ಜಿಗೆ"],
  students: 312,
  photo: "🍱",
  calories: "650 kcal",
  protein: "18g protein",
};

const facilities = [
  { id: 1, name: "Science Lab", nameKn: "ವಿಜ್ಞಾನ ಪ್ರಯೋಗಾಲಯ", emoji: "🔬", desc: "Equipped with microscopes & models", descKn: "ಮೈಕ್ರೋಸ್ಕೋಪ್ & ಮಾದರಿಗಳು", color: "#E8F5E9", accent: "#2E8B57" },
  { id: 2, name: "Smart Classroom", nameKn: "ಸ್ಮಾರ್ಟ್ ತರಗತಿ", emoji: "💻", desc: "Projectors & digital boards", descKn: "ಪ್ರೊಜೆಕ್ಟರ್ & ಡಿಜಿಟಲ್ ಬೋರ್ಡ್", color: "#E3F2FD", accent: "#1565C0" },
  { id: 3, name: "Library", nameKn: "ಗ್ರಂಥಾಲಯ", emoji: "📚", desc: "2000+ books in Kannada & English", descKn: "2000+ ಪುಸ್ತಕಗಳು", color: "#FFF3E0", accent: "#F4A300" },
  { id: 4, name: "Sports Ground", nameKn: "ಕ್ರೀಡಾಂಗಣ", emoji: "⚽", desc: "Football, cricket & kabaddi", descKn: "ಫುಟ್ಬಾಲ್, ಕ್ರಿಕೆಟ್ & ಕಬಡ್ಡಿ", color: "#FCE4EC", accent: "#C62828" },
  { id: 5, name: "Clean Toilets", nameKn: "ಶೌಚಾಲಯ", emoji: "🚿", desc: "Separate for boys & girls", descKn: "ಹುಡುಗರು & ಹುಡುಗಿಯರಿಗೆ ಪ್ರತ್ಯೇಕ", color: "#E0F7FA", accent: "#00838F" },
  { id: 6, name: "Computer Lab", nameKn: "ಕಂಪ್ಯೂಟರ್ ಲ್ಯಾಬ್", emoji: "🖥️", desc: "30 computers with internet", descKn: "ಇಂಟರ್ನೆಟ್ ಸಹಿತ 30 ಕಂಪ್ಯೂಟರ್", color: "#EDE7F6", accent: "#6A1B9A" },
];

const stars = [
  { name: "Kavya Nayak", nameKn: "ಕಾವ್ಯ ನಾಯಕ", grade: "Grade 7", gradeKn: "7ನೇ ತರಗತಿ", achievement: "Student of the Week", achievementKn: "ವಾರದ ವಿದ್ಯಾರ್ಥಿ", emoji: "⭐", color: "#FFF8E1", border: "#F4A300", icon: "🏆" },
  { name: "Raju Gowda", nameKn: "ರಾಜು ಗೌಡ", grade: "Grade 9", gradeKn: "9ನೇ ತರಗತಿ", achievement: "Cricket Champion", achievementKn: "ಕ್ರಿಕೆಟ್ ಚಾಂಪಿಯನ್", emoji: "🏏", color: "#E8F5E9", border: "#2E8B57", icon: "🥇" },
  { name: "Meena Patil", nameKn: "ಮೀನಾ ಪಾಟೀಲ್", grade: "Grade 8", gradeKn: "8ನೇ ತರಗತಿ", achievement: "Science Project Winner", achievementKn: "ವಿಜ್ಞಾನ ಯೋಜನೆ ವಿಜೇತ", emoji: "🔬", color: "#E3F2FD", border: "#1565C0", icon: "🎖️" },
  { name: "Arjun Kumar", nameKn: "ಅರ್ಜುನ್ ಕುಮಾರ್", grade: "Grade 6", gradeKn: "6ನೇ ತರಗತಿ", achievement: "Drawing Competition Winner", achievementKn: "ಚಿತ್ರಕಲೆ ಸ್ಪರ್ಧೆ ವಿಜೇತ", emoji: "🎨", color: "#FCE4EC", border: "#C62828", icon: "🏅" },
];

// ---- Screens ----

function HomeScreen({ lang, t, setScreen }) {
  const updates = [
    { icon: "🍱", label: t.todayMeal, sub: t.mealDesc, screen: "meals", color: "#FF6B35" },
    { icon: "🏫", label: t.facilityTour, sub: t.facilityDesc, screen: "facilities", color: "#1565C0" },
    { icon: "⭐", label: t.studentStars, sub: t.starsDesc, screen: "stars", color: "#F4A300" },
    { icon: "💬", label: t.sendFeedback, sub: t.feedbackDesc, screen: "feedback", color: "#2E8B57" },
  ];
  return (
    <div style={{ padding: "0 0 80px" }}>
      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg, #FF6B35 0%, #F4A300 50%, #2E8B57 100%)", padding: "32px 20px 28px", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, opacity: 0.1, backgroundImage: "radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)", backgroundSize: "40px 40px" }} />
        <div style={{ fontSize: 48, marginBottom: 8 }}>🏫</div>
        <h1 style={{ color: "white", fontSize: 22, fontWeight: 700, margin: "0 0 4px", fontFamily: "'Noto Sans Kannada', sans-serif" }}>{t.appName}</h1>
        <p style={{ color: "rgba(255,255,255,0.9)", fontSize: 14, margin: 0 }}>{t.tagline}</p>
        <div style={{ display: "flex", justifyContent: "center", gap: 24, marginTop: 16 }}>
          {[["312", "Students"], ["18", "Teachers"], ["6", "Facilities"]].map(([n, l]) => (
            <div key={l} style={{ textAlign: "center" }}>
              <div style={{ color: "white", fontSize: 20, fontWeight: 700 }}>{n}</div>
              <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 11 }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Today's highlight */}
      <div style={{ margin: "16px 16px 8px" }}>
        <div style={{ background: "#FFF3E0", border: "1px solid #FFE0B2", borderRadius: 12, padding: "12px 16px", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ fontSize: 28 }}>🍱</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 13, color: "#E65100" }}>{t.todayMeal}</div>
            <div style={{ fontSize: 12, color: "#BF360C", marginTop: 2 }}>{lang === "kn" ? mealData.itemsKn.join(" • ") : mealData.items.join(" • ")}</div>
          </div>
          <button onClick={() => setScreen("meals")} style={{ background: "#FF6B35", color: "white", border: "none", borderRadius: 8, padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>{t.viewAll}</button>
        </div>
      </div>

      {/* Quick actions */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, padding: "8px 16px" }}>
        {updates.map((u) => (
          <button key={u.screen} onClick={() => setScreen(u.screen)} style={{ background: "white", border: `1.5px solid ${u.color}20`, borderRadius: 14, padding: "20px 16px", textAlign: "left", cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>{u.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.text }}>{u.label}</div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 4, lineHeight: 1.4 }}>{u.sub}</div>
            <div style={{ marginTop: 10, display: "inline-block", background: u.color, color: "white", borderRadius: 6, padding: "3px 10px", fontSize: 11, fontWeight: 600 }}>Open →</div>
          </button>
        ))}
      </div>

      {/* Notice board */}
      <div style={{ margin: "8px 16px", background: "#E8F5E9", border: "1px solid #C8E6C9", borderRadius: 12, padding: "12px 16px" }}>
        <div style={{ fontWeight: 700, fontSize: 13, color: "#1B5E20", marginBottom: 8 }}>📌 Notice Board</div>
        {["Annual Sports Day - May 15, 2026", "Parent-Teacher Meeting - May 20, 2026", "Science Exhibition - June 1, 2026"].map((n) => (
          <div key={n} style={{ fontSize: 12, color: "#2E7D32", padding: "4px 0", borderBottom: "1px solid #C8E6C920" }}>• {n}</div>
        ))}
      </div>
    </div>
  );
}

function MealsScreen({ lang, t }) {
  const [alreadyUpdated] = useState(true);
  const items = lang === "kn" ? mealData.itemsKn : mealData.items;
  return (
    <div style={{ padding: "16px 16px 80px" }}>
      <h2 style={{ fontSize: 18, fontWeight: 700, color: COLORS.text, margin: "0 0 16px" }}>🍱 {t.todayMeal}</h2>

      {/* Photo card */}
      <div style={{ background: "linear-gradient(135deg, #FF6B35, #F4A300)", borderRadius: 16, padding: 24, textAlign: "center", marginBottom: 16 }}>
        <div style={{ fontSize: 80 }}>🍛</div>
        <div style={{ color: "white", fontWeight: 700, fontSize: 16, marginTop: 8 }}>{t.menuToday}</div>
        <div style={{ color: "rgba(255,255,255,0.85)", fontSize: 12, marginTop: 4 }}>{mealData.date}</div>
        <div style={{ display: "flex", justifyContent: "center", gap: 16, marginTop: 12 }}>
          <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 8, padding: "6px 14px", color: "white", fontSize: 12 }}>🔥 {mealData.calories}</div>
          <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 8, padding: "6px 14px", color: "white", fontSize: 12 }}>💪 {mealData.protein}</div>
        </div>
      </div>

      {/* Menu items */}
      <div style={{ background: "white", borderRadius: 14, border: "1px solid #EEE", overflow: "hidden", marginBottom: 16 }}>
        {items.map((item, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", padding: "14px 16px", borderBottom: i < items.length - 1 ? "1px solid #F5F5F5" : "none" }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: "#FFF3E0", display: "flex", alignItems: "center", justifyContent: "center", marginRight: 12, fontSize: 16 }}>
              {["🍚", "🥘", "🫓", "🍌", "🥛"][i]}
            </div>
            <span style={{ fontSize: 14, color: COLORS.text, fontWeight: 500 }}>{item}</span>
            <div style={{ marginLeft: "auto", width: 8, height: 8, borderRadius: "50%", background: "#4CAF50" }} />
          </div>
        ))}
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <div style={{ background: "#E8F5E9", borderRadius: 12, padding: "14px 16px", textAlign: "center" }}>
          <div style={{ fontSize: 28, fontWeight: 700, color: "#2E8B57" }}>{mealData.students}</div>
          <div style={{ fontSize: 12, color: "#388E3C" }}>Students Fed Today</div>
        </div>
        <div style={{ background: "#E3F2FD", borderRadius: 12, padding: "14px 16px", textAlign: "center" }}>
          <div style={{ fontSize: 28, fontWeight: 700, color: "#1565C0" }}>100%</div>
          <div style={{ fontSize: 12, color: "#1976D2" }}>Attendance Rate</div>
        </div>
      </div>

      {alreadyUpdated && (
        <div style={{ marginTop: 12, background: "#E8F5E9", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#2E7D32", display: "flex", alignItems: "center", gap: 8 }}>
          <span>✅</span> Daily meal update posted. Next update tomorrow.
        </div>
      )}
    </div>
  );
}

function FacilitiesScreen({ lang, t }) {
  const [active, setActive] = useState(null);
  return (
    <div style={{ padding: "16px 16px 80px" }}>
      <h2 style={{ fontSize: 18, fontWeight: 700, color: COLORS.text, margin: "0 0 16px" }}>🏫 {t.facilityTour}</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {facilities.map((f) => (
          <button key={f.id} onClick={() => setActive(active === f.id ? null : f.id)}
            style={{ background: active === f.id ? f.color : "white", border: `2px solid ${active === f.id ? f.accent : "#EEE"}`, borderRadius: 14, padding: "18px 14px", textAlign: "left", cursor: "pointer", transition: "all 0.2s" }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>{f.emoji}</div>
            <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.text }}>{lang === "kn" ? f.nameKn : f.name}</div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 4, lineHeight: 1.4 }}>{lang === "kn" ? f.descKn : f.desc}</div>
            {active === f.id && (
              <div style={{ marginTop: 10, background: f.accent, color: "white", borderRadius: 6, padding: "4px 10px", fontSize: 11, fontWeight: 600, display: "inline-block" }}>
                ✓ Verified Good
              </div>
            )}
          </button>
        ))}
      </div>
      <div style={{ marginTop: 16, background: "#E3F2FD", borderRadius: 12, padding: "12px 14px", fontSize: 12, color: "#0D47A1" }}>
        💡 Tap any facility to mark it as verified. Last inspection: May 1, 2026
      </div>
    </div>
  );
}

function StarsScreen({ lang, t }) {
  return (
    <div style={{ padding: "16px 16px 80px" }}>
      <h2 style={{ fontSize: 18, fontWeight: 700, color: COLORS.text, margin: "0 0 4px" }}>⭐ {t.studentStars}</h2>
      <p style={{ fontSize: 13, color: COLORS.muted, margin: "0 0 16px" }}>Celebrating our week's champions!</p>
      {stars.map((s, i) => (
        <div key={i} style={{ background: s.color, border: `1.5px solid ${s.border}40`, borderRadius: 14, padding: "16px", marginBottom: 12, display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 56, height: 56, borderRadius: "50%", background: s.border, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, flexShrink: 0 }}>
            {s.emoji}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.text }}>{lang === "kn" ? s.nameKn : s.name}</div>
            <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>{lang === "kn" ? s.gradeKn : s.grade}</div>
            <div style={{ marginTop: 6, display: "inline-flex", alignItems: "center", gap: 4, background: s.border, color: "white", borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 600 }}>
              {s.icon} {lang === "kn" ? s.achievementKn : s.achievement}
            </div>
          </div>
        </div>
      ))}
      <div style={{ background: "#FFF3E0", borderRadius: 12, padding: "14px 16px", marginTop: 8, textAlign: "center" }}>
        <div style={{ fontSize: 24, marginBottom: 6 }}>🌟</div>
        <div style={{ fontWeight: 600, fontSize: 13, color: "#E65100" }}>Nominate a Student Star</div>
        <div style={{ fontSize: 12, color: "#BF360C", marginTop: 4 }}>Contact the headmaster to nominate a student for next week's star!</div>
      </div>
    </div>
  );
}

function FeedbackScreen({ lang, t }) {
  const [text, setText] = useState("");
  const [anon, setAnon] = useState(true);
  const [category, setCategory] = useState("general");
  const [submitted, setSubmitted] = useState(false);

  const categories = [
    { id: "general", label: "General", emoji: "💬" },
    { id: "meals", label: "Meals", emoji: "🍱" },
    { id: "facilities", label: "Facilities", emoji: "🏫" },
    { id: "safety", label: "Safety", emoji: "🛡️" },
  ];

  if (submitted) {
    return (
      <div style={{ padding: "60px 24px", textAlign: "center" }}>
        <div style={{ fontSize: 72, marginBottom: 16 }}>🙏</div>
        <h3 style={{ fontWeight: 700, fontSize: 20, color: COLORS.green, margin: "0 0 8px" }}>{t.successMsg}</h3>
        <p style={{ fontSize: 14, color: COLORS.muted }}>Your feedback helps improve our school.</p>
        <button onClick={() => { setSubmitted(false); setText(""); }} style={{ marginTop: 20, background: COLORS.green, color: "white", border: "none", borderRadius: 12, padding: "12px 28px", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
          Submit Another
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: "16px 16px 80px" }}>
      <h2 style={{ fontSize: 18, fontWeight: 700, color: COLORS.text, margin: "0 0 4px" }}>💬 {t.sendFeedback}</h2>
      <p style={{ fontSize: 13, color: COLORS.muted, margin: "0 0 20px" }}>{t.feedbackDesc}</p>

      {/* Category selector */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.text, marginBottom: 8 }}>Category</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {categories.map((c) => (
            <button key={c.id} onClick={() => setCategory(c.id)}
              style={{ background: category === c.id ? COLORS.green : "white", color: category === c.id ? "white" : COLORS.text, border: `1.5px solid ${category === c.id ? COLORS.green : "#DDD"}`, borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
              {c.emoji} {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Text input */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.text, marginBottom: 8 }}>Your Message</div>
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={t.placeholder}
          style={{ width: "100%", minHeight: 130, border: "1.5px solid #DDD", borderRadius: 12, padding: "12px 14px", fontSize: 14, fontFamily: "inherit", resize: "vertical", outline: "none", boxSizing: "border-box" }} />
      </div>

      {/* Anonymous toggle */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24, background: "#F5F5F5", borderRadius: 12, padding: "12px 14px" }}>
        <div onClick={() => setAnon(!anon)} style={{ width: 44, height: 24, borderRadius: 12, background: anon ? COLORS.green : "#CCC", cursor: "pointer", position: "relative", transition: "background 0.2s", flexShrink: 0 }}>
          <div style={{ width: 18, height: 18, borderRadius: "50%", background: "white", position: "absolute", top: 3, left: anon ? 23 : 3, transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
        </div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.text }}>{t.anonymous}</div>
          <div style={{ fontSize: 11, color: COLORS.muted }}>Your identity will {anon ? "not be" : "be"} shared with the school committee.</div>
        </div>
      </div>

      <button onClick={() => text.trim() && setSubmitted(true)}
        style={{ width: "100%", background: text.trim() ? COLORS.green : "#CCC", color: "white", border: "none", borderRadius: 14, padding: "16px", fontSize: 15, fontWeight: 700, cursor: text.trim() ? "pointer" : "default" }}>
        {t.submit} →
      </button>

      <div style={{ marginTop: 16, background: "#E3F2FD", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#1565C0" }}>
        🔒 All feedback is reviewed by the SDMC committee monthly.
      </div>
    </div>
  );
}

// ---- Main App ----

const screens = ["home", "meals", "facilities", "stars", "feedback"];
const navItems = [
  { id: "home", icon: "🏠" },
  { id: "meals", icon: "🍱" },
  { id: "facilities", icon: "🏫" },
  { id: "stars", icon: "⭐" },
  { id: "feedback", icon: "💬" },
];

export default function ShaleNamma() {
  const [screen, setScreen] = useState("home");
  const [lang, setLang] = useState("en");
  const t = translations[lang];

  const navLabels = {
    home: t.home,
    meals: t.meals,
    facilities: t.facilities,
    stars: t.stars,
    feedback: t.feedback,
  };

  const renderScreen = () => {
    if (screen === "home") return <HomeScreen lang={lang} t={t} setScreen={setScreen} />;
    if (screen === "meals") return <MealsScreen lang={lang} t={t} />;
    if (screen === "facilities") return <FacilitiesScreen lang={lang} t={t} />;
    if (screen === "stars") return <StarsScreen lang={lang} t={t} />;
    if (screen === "feedback") return <FeedbackScreen lang={lang} t={t} />;
  };

  return (
    <div style={{ maxWidth: 420, margin: "0 auto", background: COLORS.bg, minHeight: "100vh", fontFamily: "'Noto Sans', 'Segoe UI', sans-serif", position: "relative" }}>
      {/* Status bar */}
      <div style={{ background: "#FF6B35", padding: "8px 16px 4px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ color: "white", fontSize: 11, opacity: 0.9 }}>9:41 AM</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button onClick={() => setLang(lang === "en" ? "kn" : "en")}
            style={{ background: "rgba(255,255,255,0.25)", color: "white", border: "none", borderRadius: 10, padding: "3px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
            {lang === "en" ? "ಕನ್ನಡ" : "English"}
          </button>
          <span style={{ color: "white", fontSize: 13 }}>📶 🔋</span>
        </div>
      </div>

      {/* Header */}
      <div style={{ background: "#FF6B35", padding: "8px 16px 14px", display: "flex", alignItems: "center", gap: 10 }}>
        {screen !== "home" && (
          <button onClick={() => setScreen("home")} style={{ background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 8, color: "white", fontSize: 16, cursor: "pointer", padding: "4px 10px" }}>←</button>
        )}
        <div>
          <div style={{ color: "white", fontWeight: 700, fontSize: 15 }}>{t.appName}</div>
          <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 11 }}>Govt. Higher Primary School, Bengaluru</div>
        </div>
      </div>

      {/* Content */}
      <div style={{ overflowY: "auto" }}>{renderScreen()}</div>

      {/* Bottom nav */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 420, background: "white", borderTop: "1px solid #EEE", display: "flex", zIndex: 100, boxShadow: "0 -2px 12px rgba(0,0,0,0.08)" }}>
        {navItems.map((n) => (
          <button key={n.id} onClick={() => setScreen(n.id)}
            style={{ flex: 1, padding: "10px 0 12px", border: "none", background: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{ fontSize: 20, filter: screen === n.id ? "none" : "grayscale(1)", opacity: screen === n.id ? 1 : 0.5 }}>{n.icon}</div>
            <div style={{ fontSize: 9, fontWeight: screen === n.id ? 700 : 400, color: screen === n.id ? COLORS.saffron : COLORS.muted }}>{navLabels[n.id]}</div>
            {screen === n.id && <div style={{ width: 4, height: 4, borderRadius: "50%", background: COLORS.saffron }} />}
          </button>
        ))}
      </div>
    </div>
  );
}
