package com.shalenamma.proud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MealsScreen(
    language: String,
    strings: Map<String, String>
) {
    val mealItems = if (language == "kn") {
        listOf(
            "ಅನ್ನ & ಸಾಂಬಾರ್",
            "ತರಕಾರಿ ಕರ್ರಿ",
            "ಪಾಪಡ",
            "ಬಾಳೆಹಣ್ಣು",
            "ಮಜ್ಜಿಗೆ"
        )
    } else {
        listOf(
            "Rice & Sambar",
            "Vegetable Curry",
            "Papad",
            "Banana",
            "Buttermilk"
        )
    }

    val mealEmojis = listOf("🍚", "🥘", "🫓", "🍌", "🥛")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Header
        Text(
            "🍱 ${strings["todayMeal"] ?: ""}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A2E),
            modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 16.dp)
        )

        // Photo Card with Gradient
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFFF6B35)
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFFF6B35),
                                Color(0xFFF4A300)
                            )
                        )
                    )
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🍛", fontSize = 80.sp)
                    Text(
                        strings["menuToday"] ?: "",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        "May 5, 2026",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    // Nutritional badges
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Badge(
                            icon = "🔥",
                            label = strings["calendar"] ?: "",
                            backgroundColor = Color.White.copy(alpha = 0.2f)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Badge(
                            icon = "💪",
                            label = strings["protein"] ?: "",
                            backgroundColor = Color.White.copy(alpha = 0.2f)
                        )
                    }
                }
            }
        }

        // Menu Items List
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFEEE))
        ) {
            Column {
                mealItems.forEachIndexed { index, item ->
                    MealItemRow(
                        icon = mealEmojis[index],
                        text = item,
                        isLast = index == mealItems.size - 1
                    )
                }
            }
        }

        // Stats Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                value = "312",
                label = strings["fed"] ?: "",
                backgroundColor = Color(0xFFE8F5E9),
                textColor = Color(0xFF2E8B57),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                value = "100%",
                label = strings["attendance"] ?: "",
                backgroundColor = Color(0xFFE3F2FD),
                textColor = Color(0xFF1565C0),
                modifier = Modifier.weight(1f)
            )
        }

        // Confirmation badge
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
            border = BorderStroke(1.dp, Color(0xFFC8E6C9))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp, 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("✅", fontSize = 16.sp)
                Text(
                    strings["nextUpdate"] ?: "",
                    fontSize = 12.sp,
                    color = Color(0xFF2E7D32)
                )
            }
        }
    }
}

@Composable
fun MealItemRow(
    icon: String,
    text: String,
    isLast: Boolean
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp, 14.dp, 14.dp, 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(Color(0xFFFFF3E0), shape = RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(icon, fontSize = 16.sp)
            }
            Text(
                text,
                fontSize = 14.sp,
                color = Color(0xFF1A1A2E),
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(Color(0xFF4CAF50), shape = RoundedCornerShape(50.dp))
            )
        }
        if (!isLast) {
            Divider(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFFF5F5F5))
            )
        }
    }
}

@Composable
fun StatCard(
    value: String,
    label: String,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(100.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                value,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            Text(
                label,
                fontSize = 12.sp,
                color = textColor,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun Badge(
    icon: String,
    label: String,
    backgroundColor: Color
) {
    Box(
        modifier = Modifier
            .background(backgroundColor, shape = RoundedCornerShape(8.dp))
            .padding(6.dp, 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(icon, fontSize = 14.sp)
            Text(
                label,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
