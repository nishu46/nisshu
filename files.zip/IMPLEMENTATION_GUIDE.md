# Shale-Namma Pride - Implementation Guide
**Complete Android App for School Transparency Portal**

---

## 📋 Table of Contents
1. [Quick Start](#quick-start)
2. [File Structure](#file-structure)
3. [Key Features Explained](#key-features-explained)
4. [Firebase Setup](#firebase-setup)
5. [Testing & QA](#testing--qa)
6. [Deployment](#deployment)
7. [Troubleshooting](#troubleshooting)

---

## 🚀 Quick Start

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34
- Kotlin 1.9.0+
- Java 17

### Step 1: Create Android Studio Project
```bash
# File > New > New Android Project
# Project name: ShaleNamma
# Package: com.shalenamma.proud
# Min SDK: 24 (Android 7.0)
# Target SDK: 34 (Android 14)
```

### Step 2: Copy Source Files
```
app/src/main/java/com/shalenamma/proud/
├── MainActivity.kt (paste provided)
├── ui/screens/
│   ├── HomeScreen.kt
│   ├── MealsScreen.kt
│   ├── FacilitiesScreen.kt
│   ├── StarsAndFeedbackScreens.kt (contains both screens)
└── data/models/
    └── DataModels.kt
```

### Step 3: Update build.gradle.kts
Replace entire file with provided `build.gradle.kts`

### Step 4: Firebase Configuration
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click "Add Project" → name it "ShaleNamma"
3. Add Android app with package `com.shalenamma.proud`
4. Download `google-services.json`
5. Place in `app/google-services.json`

### Step 5: Build & Run
```bash
# Sync Gradle
File > Sync Now

# Run
Run > Run 'app'
```

---

## 📁 File Structure

### Project Layout
```
ShaleNamma/
├── app/
│   ├── build.gradle.kts          ← Core dependencies
│   ├── google-services.json       ← Firebase config (download from console)
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/shalenamma/proud/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── data/
│   │   │   │   │   └── models/
│   │   │   │   │       └── DataModels.kt
│   │   │   │   ├── ui/
│   │   │   │   │   ├── screens/
│   │   │   │   │   │   ├── HomeScreen.kt
│   │   │   │   │   │   ├── MealsScreen.kt
│   │   │   │   │   │   ├── FacilitiesScreen.kt
│   │   │   │   │   │   └── StarsAndFeedbackScreens.kt
│   │   │   │   │   └── theme/
│   │   │   │   │       ├── Color.kt (optional, for custom colors)
│   │   │   │   │       ├── Typography.kt (optional)
│   │   │   │   │       └── Theme.kt (optional)
│   │   │   │   └── viewmodel/
│   │   │   │       └── SharedViewModel.kt (optional, for data management)
│   │   │   └── res/
│   │   │       ├── values/
│   │   │       │   ├── strings.xml
│   │   │       │   ├── colors.xml
│   │   │       │   └── dimens.xml
│   │   │       └── drawable/
│   │   └── test/
│   │       └── (unit tests)
│   └── androidTest/
│       └── (instrumented tests)
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

---

## 🎨 Key Features Explained

### 1. **Home Screen**
- Displays app name with gradient hero section
- Shows school statistics (312 students, 18 teachers, 6 facilities)
- Quick access cards to all major features
- Notice board with announcements
- Language toggle (English/Kannada)

**File:** `HomeScreen.kt`

**Key Components:**
```kotlin
// Hero section with stats
Box(background: gradient, ...) {
    Text("🏫")
    StatBox("312", "Students", Color.White)
    // ... more stats
}

// Quick action cards
QuickActionCard(icon, label, color, onClick)

// Notice board
Column {
    Text("📌 Notice Board")
    // iterate through notices
}
```

### 2. **Meals Screen**
- Daily meal photo with gradient background
- Menu items with emojis
- Nutritional info (calories, protein)
- Statistics (students fed, attendance %)
- Update confirmation badge

**File:** `MealsScreen.kt`

**Data Structure:**
```kotlin
mealItems = listOf("Rice & Sambar", "Vegetable Curry", ...)
mealEmojis = listOf("🍚", "🥘", "🫓", ...)
```

**Requirements Met:**
✅ Only one update per day (timestamp check)
✅ Anonymous (no parent data stored)
✅ Child-friendly with large emojis

### 3. **Facilities Screen**
- 2-column grid of facility tiles
- 6 facilities: Lab, Smart Class, Library, Sports, Toilets, Computer Lab
- Toggle verification with visual feedback
- Bilingual names and descriptions
- Last inspection date displayed

**File:** `FacilitiesScreen.kt`

**Features:**
```kotlin
FacilityTile(
    emoji = "🔬",
    nameEn = "Science Lab",
    nameKn = "ವಿಜ್ಞಾನ ಪ್ರಯೋಗಾಲಯ",
    color = Color(0xFFE8F5E9),  // Light green background
    accent = Color(0xFF2E8B57)   // Dark green border when verified
)
```

### 4. **Student Stars Screen**
- 4 student achievement cards
- Bilingual names, grades, achievements
- Color-coded by achievement type
- Avatar circles with emojis
- Award icons (🏆, 🥇, 🎖️, 🏅)
- Nominate button with instructions

**File:** `StarsAndFeedbackScreens.kt` (first half)

**Achievement Types:**
- Academic: Student of the Week
- Sports: Cricket Champion
- Science: Project Winner
- Arts: Drawing Competition Winner

### 5. **Feedback Screen** (Most Critical Feature)
- Category selector (General, Meals, Facilities, Safety)
- Text input for message
- Anonymous toggle with clear labeling
- Submit button (disabled when empty)
- Success confirmation screen
- SDMC privacy notice at bottom

**File:** `StarsAndFeedbackScreens.kt` (second half)

**Critical Requirements:**
✅ Only 1 update per day enforced
✅ Anonymous toggle prominently shown
✅ "Your identity will not be shared" explicit message
✅ Child-friendly text input
✅ Success feedback with 🙏 emoji
✅ SDMC monthly review notice

---

## 🔥 Firebase Setup (Detailed)

### Database Structure
```
/
├── meals/
│   └── {date}/
│       ├── id: "2026-05-05"
│       ├── date: "May 5, 2026"
│       ├── items: ["Rice & Sambar", ...]
│       ├── calories: "650 kcal"
│       ├── studentsServed: 312
│       ├── photoUrl: "gs://..."
│       └── timestamp: 1714927345000
│
├── facilities/
│   ├── {facilityId}/
│   │   ├── id: "lab1"
│   │   ├── emoji: "🔬"
│   │   ├── nameEn: "Science Lab"
│   │   ├── nameKn: "ವಿಜ್ಞಾನ ಪ್ರಯೋಗಾಲಯ"
│   │   ├── inspectionStatus: "good"
│   │   └── timestamp: 1714927345000
│   └── ...
│
├── stars/
│   ├── {starId}/
│   │   ├── id: "star1"
│   │   ├── nameEn: "Kavya Nayak"
│   │   ├── nameKn: "ಕಾವ್ಯ ನಾಯಕ"
│   │   ├── achievement: "Student of the Week"
│   │   ├── weekOf: "May 1-7, 2026"
│   │   └── timestamp: 1714927345000
│   └── ...
│
└── feedback/
    ├── {feedbackId}/
    │   ├── id: "fb1"
    │   ├── category: "meals"
    │   ├── message: "Food was good..."
    │   ├── isAnonymous: true
    │   ├── status: "pending"
    │   └── timestamp: 1714927345000
    └── ...
```

### Database Rules (Realtime)
```json
{
  "rules": {
    "meals": {
      ".read": true,
      ".write": "root.child('admins').child(auth.uid).exists()"
    },
    "facilities": {
      ".read": true,
      ".write": "root.child('admins').child(auth.uid).exists()"
    },
    "stars": {
      ".read": true,
      ".write": "root.child('admins').child(auth.uid).exists()"
    },
    "feedback": {
      ".read": false,
      ".write": true,
      ".validate": "newData.hasChildren(['category','message','isAnonymous','timestamp'])"
    },
    "admins": {
      ".read": "auth != null",
      ".write": false
    }
  }
}
```

### Storage Rules (for images)
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /meals/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth.uid != null;
    }
    match /facilities/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth.uid != null;
    }
    match /stars/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth.uid != null;
    }
  }
}
```

---

## ✅ Testing & QA

### Unit Tests Template
```kotlin
// app/src/test/java/com/shalenamma/proud/MealTest.kt
import org.junit.Test
import com.shalenamma.proud.data.models.Meal

class MealTest {
    @Test
    fun testMealCreation() {
        val meal = Meal(
            date = "May 5, 2026",
            items = listOf("Rice", "Curry"),
            studentsServed = 312
        )
        assert(meal.studentsServed == 312)
    }
    
    @Test
    fun testMealSerialization() {
        val meal = Meal(date = "2026-05-05")
        val map = meal.toMap()
        assert(map["date"] == "2026-05-05")
    }
}
```

### UI Tests Template
```kotlin
// app/src/androidTest/java/com/shalenamma/proud/HomeScreenTest.kt
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule

class HomeScreenTest {
    @get:Rule
    val composeTestRule = createComposeRule()
    
    @Test
    fun testHomeScreenRendersQuickActions() {
        composeTestRule.setContent {
            ShaleNammaTheme {
                HomeScreen(
                    onNavigate = { },
                    onLanguageToggle = { },
                    language = "en",
                    strings = english_strings
                )
            }
        }
        
        // Verify quick action cards are displayed
        composeTestRule.onNodeWithText("Today's Meal").assertIsDisplayed()
        composeTestRule.onNodeWithText("Facility Tour").assertIsDisplayed()
    }
}
```

### Manual Testing Checklist

**Navigation**
- [ ] Bottom nav bar shows all 5 items
- [ ] Screen transitions are smooth
- [ ] Back button works on non-home screens
- [ ] Language toggle switches between English/Kannada

**Home Screen**
- [ ] Gradient hero displays correctly
- [ ] Statistics (312/18/6) visible
- [ ] Quick action cards are clickable
- [ ] Notice board items display
- [ ] Language toggle button works

**Meals Screen**
- [ ] Meal photo with gradient displays
- [ ] Menu items listed with emojis
- [ ] Nutritional info badges show
- [ ] Statistics cards display
- [ ] Update confirmation badge visible

**Facilities Screen**
- [ ] 2-column grid displays 6 facilities
- [ ] Tap toggles verification state
- [ ] Color change on verified
- [ ] Bilingual names work
- [ ] Info card at bottom shows inspection date

**Stars Screen**
- [ ] 4 student cards display
- [ ] Avatar circles with colors
- [ ] Achievement badges visible
- [ ] Nominate section at bottom
- [ ] Bilingual text renders correctly

**Feedback Screen**
- [ ] Category buttons work
- [ ] Text input accepts text
- [ ] Anonymous toggle switches
- [ ] Submit button disabled when empty
- [ ] Submit shows success screen
- [ ] SDMC notice visible at bottom

---

## 🚀 Deployment

### Pre-Release Checklist
```
Security:
☐ Firebase Rules configured correctly
☐ No hardcoded API keys
☐ HTTPS enabled for all requests
☐ Data validation on all inputs

Performance:
☐ App launches in < 2 seconds
☐ No memory leaks (use Profiler)
☐ Images optimized (< 2MB per image)
☐ Database queries indexed

Functionality:
☐ All screens load without crashes
☐ Bilingual content complete
☐ Offline mode gracefully fails
☐ Images load from Firebase Storage

Testing:
☐ Tested on Android 7.0+ devices
☐ Tested on tablets
☐ Network latency tested
☐ Firebase emulator tested locally
```

### Build Release APK
```bash
# 1. Update version in build.gradle.kts
versionCode = 1
versionName = "1.0.0"

# 2. Generate signed APK
Build > Generate Signed Bundle / APK

# 3. Select Android App Bundle for Play Store
# or APK for direct installation

# 4. Create keystore (if first time)
Key store path: ~/.android/shalenamma.jks
Password: [secure password]
```

### Google Play Store Submission
1. Create Play Store account ($25 one-time fee)
2. Create new app "Shale-Namma Pride"
3. Upload signed APK/Bundle
4. Fill store listing:
   - Title: "Shale-Namma Pride"
   - Description: [School transparency portal]
   - Screenshots: 4-5 screens
   - Icon & Feature graphic
   - Content rating questionnaire
5. Pricing: Free
6. Submit for review (24-72 hours)

---

## 🔧 Troubleshooting

### Issue: App Crashes on Launch
**Solution:**
```kotlin
// Check Logcat for errors
// Most common: Missing google-services.json
// Fix: Download from Firebase Console, place in app/
```

### Issue: Firebase Data Not Loading
**Solution:**
```
1. Check Firebase Realtime Database exists
2. Verify data structure matches expectations
3. Check Firebase Rules allow read access
4. Enable Offline Persistence:
   
   FirebaseDatabase.getInstance()
       .setPersistenceEnabled(true)
```

### Issue: Images Not Showing
**Solution:**
```kotlin
// Firebase Storage Rules must allow read:
match /meals/{allPaths=**} {
    allow read: if true;
}

// Or load from public URL with Coil:
Image(
    painter = rememberImagePainter(photoUrl),
    contentDescription = null
)
```

### Issue: Language Toggle Not Working
**Solution:**
```kotlin
// Ensure strings Map is passed to composables
val strings = if (language == "en") english_strings else kannada_strings

// Pass to every screen:
HomeScreen(language = language, strings = strings, ...)
```

### Issue: Feedback Not Storing
**Solution:**
```
1. Check Firebase Authentication enabled
2. Check Realtime Database Rules allow write to /feedback:
   
   "feedback": {
       ".write": true
   }

3. Check timestamp is being captured:
   timestamp: System.currentTimeMillis()
```

---

## 📱 Hardware Requirements
- **Min RAM:** 2GB
- **Min Storage:** 50MB
- **Camera:** Required for meal photo uploads (optional for parents)
- **Network:** 3G+ (WiFi recommended)
- **Screen Size:** Optimized for 4.5" - 6.5" phones

---

## 🔐 Privacy & Security

### Data Collection
- ✅ **Anonymous Feedback:** Stored without parent name/phone
- ✅ **No Student Data:** App doesn't track individual student data
- ✅ **No Biometrics:** Face/fingerprint not used
- ✅ **HTTPS Only:** All Firebase connections encrypted
- ✅ **No Third-Party Tracking:** No Google Analytics, no ads

### GDPR Compliance
- Parents can view but not modify data
- Feedback stored securely in Firebase
- Data retention: 1 year (configurable)
- Right to access: Available through admin dashboard

---

## 📧 Support Contact
**Email:** shalenamma@school.edu.in  
**GitHub:** [School Transparency Portal](https://github.com/shalenamma)  
**Documentation:** [Full Docs](https://docs.shalenamma.edu.in)

---

## 🎓 Educational Value

This project teaches:
- ✅ Jetpack Compose UI development
- ✅ MVVM architecture patterns
- ✅ Firebase Realtime Database integration
- ✅ Bilingual app development
- ✅ Material Design 3 principles
- ✅ Android best practices

---

**Version:** 1.0.0  
**Last Updated:** May 2026  
**Status:** Production Ready

