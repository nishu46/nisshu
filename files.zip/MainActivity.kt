package com.shalenamma.proud

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import dagger.hilt.android.AndroidEntryPoint
import com.shalenamma.proud.ui.theme.ShaleNammaTheme
import com.shalenamma.proud.ui.screens.*
import com.shalenamma.proud.viewmodel.SharedViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShaleNammaTheme {
                ShaleNammaApp()
            }
        }
    }
}

@Composable
fun ShaleNammaApp(
    viewModel: SharedViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf("home") }
    var language by remember { mutableStateOf("en") }
    val context = LocalContext.current

    // Strings mapping for bilingual support
    val strings = when (language) {
        "kn" -> kannada_strings
        else -> english_strings
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (currentScreen != "splash") {
                BottomNavigationBar(
                    currentScreen = currentScreen,
                    onScreenChange = { currentScreen = it },
                    language = language
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFFFF8F0))
        ) {
            when (currentScreen) {
                "home" -> HomeScreen(
                    onNavigate = { currentScreen = it },
                    onLanguageToggle = { language = if (language == "en") "kn" else "en" },
                    language = language,
                    strings = strings
                )
                "meals" -> MealsScreen(language = language, strings = strings)
                "facilities" -> FacilitiesScreen(language = language, strings = strings)
                "stars" -> StarsScreen(language = language, strings = strings)
                "feedback" -> FeedbackScreen(language = language, strings = strings)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    currentScreen: String,
    onScreenChange: (String) -> Unit,
    language: String
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        containerColor = Color.White,
        contentColor = Color(0xFF6B7280)
    ) {
        val navItems = listOf(
            Triple("home", "🏠", if (language == "kn") "ಮನೆ" else "Home"),
            Triple("meals", "🍱", if (language == "kn") "ಊಟ" else "Meals"),
            Triple("facilities", "🏫", if (language == "kn") "ಸೌಲಭ್ಯ" else "Facilities"),
            Triple("stars", "⭐", if (language == "kn") "ತಾರೆಗಳು" else "Stars"),
            Triple("feedback", "💬", if (language == "kn") "ಪ್ರತಿಕ್ರಿಯೆ" else "Feedback"),
        )

        navItems.forEach { (screen, emoji, label) ->
            NavigationBarItem(
                selected = currentScreen == screen,
                onClick = { onScreenChange(screen) },
                icon = {
                    Text(emoji, fontSize = 20.sp)
                },
                label = {
                    Text(
                        label,
                        fontSize = 9.sp,
                        fontWeight = if (currentScreen == screen) FontWeight.Bold else FontWeight.Normal,
                        color = if (currentScreen == screen) Color(0xFFFF6B35) else Color(0xFF6B7280)
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFFFF6B35),
                    unselectedIconColor = Color(0xFF6B7280),
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}

// Bilingual string resources
val english_strings = mapOf(
    "appName" to "Shale-Namma Pride",
    "tagline" to "Our School, Our Pride",
    "home" to "Home",
    "meals" to "Meals",
    "facilities" to "Facilities",
    "stars" to "Stars",
    "feedback" to "Feedback",
    "todayMeal" to "Today's Meal",
    "mealDesc" to "Mid-day meal served to 312 students",
    "viewAll" to "View All",
    "facilityTour" to "Facility Tour",
    "facilityDesc" to "Explore our labs, library & more",
    "studentStars" to "Student Stars",
    "starsDesc" to "Celebrating our achievers",
    "sendFeedback" to "Send Feedback",
    "feedbackDesc" to "Your voice matters",
    "menuToday" to "Menu Today",
    "anonymous" to "Send Anonymously",
    "submit" to "Submit Feedback",
    "placeholder" to "Share your thoughts, suggestions or concerns...",
    "successMsg" to "Thank you! Your feedback has been received.",
    "lastUpdated" to "Last updated",
    "category" to "Category",
    "message" to "Your Message",
    "nextUpdate" to "Daily meal update posted. Next update tomorrow.",
    "inspection" to "Last inspection: May 1, 2026",
    "nominate" to "Nominate a Student Star",
    "nominateDesc" to "Contact the headmaster to nominate a student!",
    "notice" to "Notice Board",
    "sdmc" to "All feedback is reviewed by the SDMC committee monthly.",
    "verified" to "✓ Verified Good",
    "tapHint" to "Tap any facility to verify.",
    "calendar" to "650 kcal",
    "protein" to "18g protein",
    "fed" to "Students Fed Today",
    "attendance" to "Attendance Rate",
    "school" to "Govt. Higher Primary School, Bengaluru",
)

val kannada_strings = mapOf(
    "appName" to "ಶಾಲೆ-ನಮ್ಮ ಹೆಮ್ಮೆ",
    "tagline" to "ನಮ್ಮ ಶಾಲೆ, ನಮ್ಮ ಹೆಮ್ಮೆ",
    "home" to "ಮನೆ",
    "meals" to "ಊಟ",
    "facilities" to "ಸೌಲಭ್ಯಗಳು",
    "stars" to "ತಾರೆಗಳು",
    "feedback" to "ಪ್ರತಿಕ್ರಿಯೆ",
    "todayMeal" to "ಇಂದಿನ ಊಟ",
    "mealDesc" to "312 ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಊಟ ಬಡಿಸಲಾಯಿತು",
    "viewAll" to "ಎಲ್ಲಾ ನೋಡಿ",
    "facilityTour" to "ಸೌಲಭ್ಯ ಪ್ರವಾಸ",
    "facilityDesc" to "ನಮ್ಮ ಪ್ರಯೋಗಾಲಯ ಅನ್ವೇಷಿಸಿ",
    "studentStars" to "ವಿದ್ಯಾರ್ಥಿ ತಾರೆಗಳು",
    "starsDesc" to "ನಮ್ಮ ಸಾಧಕರನ್ನು ಸ್ಮರಿಸುತ್ತೇವೆ",
    "sendFeedback" to "ಪ್ರತಿಕ್ರಿಯೆ ಕಳುಹಿಸಿ",
    "feedbackDesc" to "ನಿಮ್ಮ ಧ್ವನಿ ಮುಖ್ಯ",
    "menuToday" to "ಇಂದಿನ ಮೆನು",
    "anonymous" to "ಅನಾಮಧೇಯವಾಗಿ ಕಳುಹಿಸಿ",
    "submit" to "ಸಲ್ಲಿಸಿ",
    "placeholder" to "ನಿಮ್ಮ ಆಲೋಚನೆಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಿ...",
    "successMsg" to "ಧನ್ಯವಾದಗಳು! ನಿಮ್ಮ ಪ್ರತಿಕ್ರಿಯೆ ಸ್ವೀಕರಿಸಲಾಗಿದೆ.",
    "lastUpdated" to "ಕೊನೆಯದಾಗಿ ನವೀಕರಿಸಲಾಗಿದೆ",
    "category" to "ವರ್ಗ",
    "message" to "ನಿಮ್ಮ ಸಂದೇಶ",
    "nextUpdate" to "ದೈನಂದಿನ ಊಟ ನವೀಕರಿಸಲಾಗಿದೆ.",
    "inspection" to "ಕೊನೆಯ ತಪಾಸಣೆ: ಮೇ 1, 2026",
    "nominate" to "ವಿದ್ಯಾರ್ಥಿ ತಾರೆ ನಾಮನಿರ್ದೇಶಿಸಿ",
    "nominateDesc" to "ಪ್ರಧಾನ ಶಿಕ್ಷಕರನ್ನು ಸಂಪರ್ಕಿಸಿ!",
    "notice" to "ಸೂಚನಾ ಫಲಕ",
    "sdmc" to "SDMC ಸಮಿತಿ ಪ್ರತಿ ತಿಂಗಳು ಪರಿಶೀಲಿಸುತ್ತದೆ.",
    "verified" to "✓ ಪರಿಶೀಲಿತ",
    "tapHint" to "ಯಾವುದೇ ಸೌಲಭ್ಯವನ್ನು ಟ್ಯಾಪ್ ಮಾಡಿ.",
    "calendar" to "650 ಕ್ಯಾಲೋರಿ",
    "protein" to "18ಗ್ರಾಂ ಪ್ರೋಟೀನ್",
    "fed" to "ಇಂದು ಊಟ ಬಡಿಸಿದ ವಿದ್ಯಾರ್ಥಿಗಳು",
    "attendance" to "ಹಾಜರಾತಿ ದರ",
    "school" to "ಸರಕಾರಿ ಪ್ರಾಥಮಿಕ ಶಾಲೆ, ಬೆಂಗಳೂರು",
)
