package com.shalenamma.proud.data.models

import com.google.firebase.database.IgnoreExtraProperties
import java.io.Serializable

// ---- MEAL MODEL ----
@IgnoreExtraProperties
data class Meal(
    val id: String = "",
    val date: String = "",
    val items: List<String> = emptyList(),
    val itemsKn: List<String> = emptyList(),
    val calories: String = "650 kcal",
    val protein: String = "18g",
    val studentsServed: Int = 312,
    val photoUrl: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val uploadedBy: String = "headmaster"
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "date" to date,
        "items" to items,
        "itemsKn" to itemsKn,
        "calories" to calories,
        "protein" to protein,
        "studentsServed" to studentsServed,
        "photoUrl" to photoUrl,
        "timestamp" to timestamp,
        "uploadedBy" to uploadedBy
    )
}

// ---- FACILITY MODEL ----
@IgnoreExtraProperties
data class Facility(
    val id: String = "",
    val emoji: String = "",
    val nameEn: String = "",
    val nameKn: String = "",
    val descEn: String = "",
    val descKn: String = "",
    val category: String = "", // lab, classroom, sports, etc
    val photoUrl: String = "",
    val inspectionDate: String = "",
    val inspectionStatus: String = "good", // good, needs-repair
    val capacity: String = "",
    val timestamp: Long = System.currentTimeMillis()
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "emoji" to emoji,
        "nameEn" to nameEn,
        "nameKn" to nameKn,
        "descEn" to descEn,
        "descKn" to descKn,
        "category" to category,
        "photoUrl" to photoUrl,
        "inspectionDate" to inspectionDate,
        "inspectionStatus" to inspectionStatus,
        "capacity" to capacity,
        "timestamp" to timestamp
    )
}

// ---- STAR/ACHIEVEMENT MODEL ----
@IgnoreExtraProperties
data class Star(
    val id: String = "",
    val emoji: String = "",
    val nameEn: String = "",
    val nameKn: String = "",
    val gradeEn: String = "",
    val gradeKn: String = "",
    val achievementEn: String = "",
    val achievementKn: String = "",
    val category: String = "", // academic, sports, arts, conduct
    val awardIcon: String = "", // 🏆, 🥇, 🎖️, 🏅
    val weekOf: String = "",
    val photoUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "emoji" to emoji,
        "nameEn" to nameEn,
        "nameKn" to nameKn,
        "gradeEn" to gradeEn,
        "gradeKn" to gradeKn,
        "achievementEn" to achievementEn,
        "achievementKn" to achievementKn,
        "category" to category,
        "awardIcon" to awardIcon,
        "weekOf" to weekOf,
        "photoUrl" to photoUrl,
        "timestamp" to timestamp
    )
}

// ---- FEEDBACK MODEL ----
@IgnoreExtraProperties
data class Feedback(
    val id: String = "",
    val category: String = "general", // general, meals, facilities, safety
    val message: String = "",
    val isAnonymous: Boolean = true,
    val parentName: String? = null,
    val parentPhone: String? = null,
    val studentName: String? = null,
    val studentGrade: String? = null,
    val status: String = "pending", // pending, reviewed, resolved
    val timestamp: Long = System.currentTimeMillis(),
    val reviewedBy: String? = null,
    val reviewDate: Long? = null,
    val response: String? = null
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "category" to category,
        "message" to message,
        "isAnonymous" to isAnonymous,
        "parentName" to parentName,
        "parentPhone" to parentPhone,
        "studentName" to studentName,
        "studentGrade" to studentGrade,
        "status" to status,
        "timestamp" to timestamp,
        "reviewedBy" to reviewedBy,
        "reviewDate" to reviewDate,
        "response" to response
    )
}

// ---- NOTICE MODEL ----
@IgnoreExtraProperties
data class Notice(
    val id: String = "",
    val titleEn: String = "",
    val titleKn: String = "",
    val contentEn: String = "",
    val contentKn: String = "",
    val date: String = "",
    val category: String = "", // event, holiday, announcement
    val timestamp: Long = System.currentTimeMillis()
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "titleEn" to titleEn,
        "titleKn" to titleKn,
        "contentEn" to contentEn,
        "contentKn" to contentKn,
        "date" to date,
        "category" to category,
        "timestamp" to timestamp
    )
}

// ---- SCHOOL INFO MODEL ----
@IgnoreExtraProperties
data class SchoolInfo(
    val schoolName: String = "Govt. Higher Primary School",
    val location: String = "Bengaluru",
    val totalStudents: Int = 312,
    val totalTeachers: Int = 18,
    val totalFacilities: Int = 6,
    val principalName: String = "",
    val schoolEmail: String = "school@education.gov.in",
    val schoolPhone: String = "",
    val established: String = "1975",
    val about: String = ""
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "schoolName" to schoolName,
        "location" to location,
        "totalStudents" to totalStudents,
        "totalTeachers" to totalTeachers,
        "totalFacilities" to totalFacilities,
        "principalName" to principalName,
        "schoolEmail" to schoolEmail,
        "schoolPhone" to schoolPhone,
        "established" to established,
        "about" to about
    )
}

// ---- ATTENDANCE MODEL ----
@IgnoreExtraProperties
data class DailyAttendance(
    val date: String = "",
    val totalPresent: Int = 0,
    val totalAbsent: Int = 0,
    val attendancePercentage: Float = 0f,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "date" to date,
        "totalPresent" to totalPresent,
        "totalAbsent" to totalAbsent,
        "attendancePercentage" to attendancePercentage,
        "timestamp" to timestamp
    )
}

// ---- FEEDBACK SUMMARY MODEL (for SDMC Dashboard) ----
@IgnoreExtraProperties
data class FeedbackSummary(
    val totalFeedback: Int = 0,
    val mealsFeedback: Int = 0,
    val facilitiesFeedback: Int = 0,
    val safetyFeedback: Int = 0,
    val generalFeedback: Int = 0,
    val resolvedFeedback: Int = 0,
    val pendingFeedback: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable {
    fun toMap(): Map<String, Any?> = mapOf(
        "totalFeedback" to totalFeedback,
        "mealsFeedback" to mealsFeedback,
        "facilitiesFeedback" to facilitiesFeedback,
        "safetyFeedback" to safetyFeedback,
        "generalFeedback" to generalFeedback,
        "resolvedFeedback" to resolvedFeedback,
        "pendingFeedback" to pendingFeedback,
        "timestamp" to timestamp
    )
}
