package com.shalenamma.proud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit,
    onLanguageToggle: () -> Unit,
    language: String,
    strings: Map<String, String>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Hero Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFF6B35),
                            Color(0xFFF4A300),
                            Color(0xFF2E8B57)
                        )
                    )
                )
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("🏫", fontSize = 52.sp, modifier = Modifier.padding(bottom = 8.dp))
                Text(
                    strings["appName"] ?: "",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    strings["tagline"] ?: "",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.9f)
                )
                
                // Stats
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatBox("312", strings["students"] ?: "Students", Color.White)
                    StatBox("18", strings["teachers"] ?: "Teachers", Color.White)
                    StatBox("6", strings["facilities"] ?: "Facilities", Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Language Toggle Button
        Button(
            onClick = onLanguageToggle,
            modifier = Modifier
                .align(Alignment.End)
                .padding(end = 16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFFF6B35)
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                if (language == "en") "ಕನ್ನಡ" else "English",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }

        // Meal Highlight Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clickable { onNavigate("meals") },
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFFFF3E0)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("🍱", fontSize = 28.sp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        strings["todayMeal"] ?: "",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFFE65100)
                    )
                    Text(
                        strings["mealDesc"] ?: "",
                        fontSize = 11.sp,
                        color = Color(0xFFBF360C),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                Button(
                    onClick = { onNavigate("meals") },
                    modifier = Modifier.size(height = 32.dp, width = 80.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6B35)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        strings["viewAll"] ?: "",
                        fontSize = 10.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Quick Action Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp, 8.dp, 8.dp, 80.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    icon = "🍱",
                    label = strings["todayMeal"] ?: "",
                    color = Color(0xFFFF6B35),
                    onClick = { onNavigate("meals") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionCard(
                    icon = "🏫",
                    label = strings["facilityTour"] ?: "",
                    color = Color(0xFF1565C0),
                    onClick = { onNavigate("facilities") },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    icon = "⭐",
                    label = strings["studentStars"] ?: "",
                    color = Color(0xFFF4A300),
                    onClick = { onNavigate("stars") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionCard(
                    icon = "💬",
                    label = strings["sendFeedback"] ?: "",
                    color = Color(0xFF2E8B57),
                    onClick = { onNavigate("feedback") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Notice Board
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFE8F5E9)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    "📌 ${strings["notice"] ?: ""}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF1B5E20),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                val notices = listOf(
                    "Annual Sports Day - May 15, 2026",
                    "Parent-Teacher Meeting - May 20, 2026",
                    "Science Exhibition - June 1, 2026"
                )
                notices.forEach { notice ->
                    Text(
                        "• $notice",
                        fontSize = 11.sp,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatBox(value: String, label: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(8.dp)
    ) {
        Text(
            value,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            label,
            fontSize = 11.sp,
            color = color.copy(alpha = 0.9f)
        )
    }
}

@Composable
fun QuickActionCard(
    icon: String,
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .height(140.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.material3.BorderStroke(
            1.5.dp,
            color.copy(alpha = 0.2f)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 32.sp, modifier = Modifier.padding(bottom = 8.dp))
            Text(
                label,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFF1A1A2E),
                maxLines = 2,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Box(
                modifier = Modifier
                    .background(color, shape = RoundedCornerShape(6.dp))
                    .padding(3.dp, 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Open →",
                    fontSize = 10.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
