package com.shalenamma.proud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ==== STARS SCREEN ====

data class Star(
    val emoji: String,
    val icon: String,
    val nameEn: String,
    val nameKn: String,
    val gradeEn: String,
    val gradeKn: String,
    val achEn: String,
    val achKn: String,
    val color: Color,
    val border: Color
)

@Composable
fun StarsScreen(
    language: String,
    strings: Map<String, String>
) {
    val stars = listOf(
        Star(
            emoji = "⭐",
            icon = "🏆",
            nameEn = "Kavya Nayak",
            nameKn = "ಕಾವ್ಯ ನಾಯಕ",
            gradeEn = "Grade 7",
            gradeKn = "7ನೇ ತರಗತಿ",
            achEn = "Student of the Week",
            achKn = "ವಾರದ ವಿದ್ಯಾರ್ಥಿ",
            color = Color(0xFFFFF8E1),
            border = Color(0xFFF4A300)
        ),
        Star(
            emoji = "🏏",
            icon = "🥇",
            nameEn = "Raju Gowda",
            nameKn = "ರಾಜು ಗೌಡ",
            gradeEn = "Grade 9",
            gradeKn = "9ನೇ ತರಗತಿ",
            achEn = "Cricket Champion",
            achKn = "ಕ್ರಿಕೆಟ್ ಚಾಂಪಿಯನ್",
            color = Color(0xFFE8F5E9),
            border = Color(0xFF2E8B57)
        ),
        Star(
            emoji = "🔬",
            icon = "🎖️",
            nameEn = "Meena Patil",
            nameKn = "ಮೀನಾ ಪಾಟೀಲ್",
            gradeEn = "Grade 8",
            gradeKn = "8ನೇ ತರಗತಿ",
            achEn = "Science Project Winner",
            achKn = "ವಿಜ್ಞಾನ ಯೋಜನೆ ವಿಜೇತ",
            color = Color(0xFFE3F2FD),
            border = Color(0xFF1565C0)
        ),
        Star(
            emoji = "🎨",
            icon = "🏅",
            nameEn = "Arjun Kumar",
            nameKn = "ಅರ್ಜುನ್ ಕುಮಾರ್",
            gradeEn = "Grade 6",
            gradeKn = "6ನೇ ತರಗತಿ",
            achEn = "Drawing Competition Winner",
            achKn = "ಚಿತ್ರಕಲೆ ಸ್ಪರ್ಧೆ ವಿಜೇತ",
            color = Color(0xFFFFE0E6),
            border = Color(0xFFC62828)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Header
        Text(
            "⭐ ${strings["studentStars"] ?: ""}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A2E),
            modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 4.dp)
        )
        Text(
            "Celebrating our week's champions!",
            fontSize = 13.sp,
            color = Color(0xFF6B7280),
            modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 16.dp)
        )

        // Star Cards
        stars.forEach { star ->
            StarCard(
                star = star,
                language = language,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp, 8.dp)
            )
        }

        // Nominate Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
            border = BorderStroke(1.dp, Color(0xFFFFE0B2))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("🌟", fontSize = 24.sp, modifier = Modifier.padding(bottom = 6.dp))
                Text(
                    strings["nominate"] ?: "",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFFE65100),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    strings["nominateDesc"] ?: "",
                    fontSize = 11.sp,
                    color = Color(0xFFBF360C)
                )
            }
        }
    }
}

@Composable
fun StarCard(
    star: Star,
    language: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(110.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = star.color),
        border = BorderStroke(1.5.dp, star.border.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(star.border, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(star.emoji, fontSize = 24.sp)
            }

            // Content
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    if (language == "kn") star.nameKn else star.nameEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF1A1A2E)
                )
                Text(
                    if (language == "kn") star.gradeKn else star.gradeEn,
                    fontSize = 11.sp,
                    color = Color(0xFF6B7280),
                    modifier = Modifier.padding(top = 2.dp)
                )
                Box(
                    modifier = Modifier
                        .background(star.border, shape = RoundedCornerShape(14.dp))
                        .padding(3.dp, 6.dp)
                        .padding(top = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(star.icon, fontSize = 12.sp)
                        Text(
                            if (language == "kn") star.achKn else star.achEn,
                            fontSize = 9.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==== FEEDBACK SCREEN ====

@Composable
fun FeedbackScreen(
    language: String,
    strings: Map<String, String>
) {
    var feedbackText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("general") }
    var isAnonymous by remember { mutableStateOf(true) }
    var isSubmitted by remember { mutableStateOf(false) }

    val categories = listOf(
        Triple("general", "💬", if (language == "kn") "ಸಾಮಾನ್ಯ" else "General"),
        Triple("meals", "🍱", if (language == "kn") "ಊಟ" else "Meals"),
        Triple("facilities", "🏫", if (language == "kn") "ಸೌಲಭ್ಯ" else "Facilities"),
        Triple("safety", "🛡️", if (language == "kn") "ಸುರಕ್ಷತೆ" else "Safety")
    )

    if (isSubmitted) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("🙏", fontSize = 72.sp, modifier = Modifier.padding(bottom = 16.dp))
            Text(
                strings["successMsg"] ?: "",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color(0xFF2E8B57),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                "Your feedback helps improve our school.",
                fontSize = 13.sp,
                color = Color(0xFF6B7280)
            )
            Button(
                onClick = {
                    isSubmitted = false
                    feedbackText = ""
                },
                modifier = Modifier.padding(top = 20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E8B57))
            ) {
                Text("Submit Another", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 80.dp)
        ) {
            // Header
            Text(
                "💬 ${strings["sendFeedback"] ?: ""}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A2E),
                modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 4.dp)
            )
            Text(
                strings["feedbackDesc"] ?: "",
                fontSize = 12.sp,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 16.dp)
            )

            // Category Selector
            Column(modifier = Modifier.padding(16.dp, 0.dp)) {
                Text(
                    strings["category"] ?: "",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A1A2E),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { (catId, emoji, label) ->
                        FilterChip(
                            selected = selectedCategory == catId,
                            onClick = { selectedCategory = catId },
                            label = {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(emoji, fontSize = 14.sp)
                                    Text(label, fontSize = 11.sp)
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF2E8B57),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Text Input
            Column(modifier = Modifier.padding(16.dp, 0.dp)) {
                Text(
                    strings["message"] ?: "",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A1A2E),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                OutlinedTextField(
                    value = feedbackText,
                    onValueChange = { feedbackText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    placeholder = { Text(strings["placeholder"] ?: "", fontSize = 12.sp) },
                    shape = RoundedCornerShape(12.dp),
                    maxLines = 5
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Anonymous Toggle
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Switch(
                        checked = isAnonymous,
                        onCheckedChange = { isAnonymous = it }
                    )
                    Column {
                        Text(
                            strings["anonymous"] ?: "",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1A1A2E)
                        )
                        Text(
                            if (isAnonymous) "Your identity will not be shared." else "Your identity will be shared.",
                            fontSize = 10.sp,
                            color = Color(0xFF6B7280)
                        )
                    }
                }
            }

            // Submit Button
            Button(
                onClick = { isSubmitted = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(48.dp),
                enabled = feedbackText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2E8B57),
                    disabledContainerColor = Color(0xFFCCC)
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    "${strings["submit"] ?: ""} →",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Info Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
                border = BorderStroke(1.dp, Color(0xFFBBDEFB))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("🔒", fontSize = 14.sp)
                    Text(
                        strings["sdmc"] ?: "",
                        fontSize = 11.sp,
                        color = Color(0xFF1565C0)
                    )
                }
            }
        }
    }
}
