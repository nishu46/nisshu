package com.shalenamma.proud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Facility(
    val emoji: String,
    val nameEn: String,
    val nameKn: String,
    val descEn: String,
    val descKn: String,
    val color: Color,
    val accent: Color
)

@Composable
fun FacilitiesScreen(
    language: String,
    strings: Map<String, String>
) {
    val facilities = listOf(
        Facility(
            emoji = "🔬",
            nameEn = "Science Lab",
            nameKn = "ವಿಜ್ಞಾನ ಪ್ರಯೋಗಾಲಯ",
            descEn = "Equipped with microscopes & models",
            descKn = "ಮೈಕ್ರೋಸ್ಕೋಪ್ & ಮಾದರಿಗಳು",
            color = Color(0xFFE8F5E9),
            accent = Color(0xFF2E8B57)
        ),
        Facility(
            emoji = "💻",
            nameEn = "Smart Classroom",
            nameKn = "ಸ್ಮಾರ್ಟ್ ತರಗತಿ",
            descEn = "Projectors & digital boards",
            descKn = "ಪ್ರೊಜೆಕ್ಟರ್ & ಡಿಜಿಟಲ್ ಬೋರ್ಡ್",
            color = Color(0xFFE3F2FD),
            accent = Color(0xFF1565C0)
        ),
        Facility(
            emoji = "📚",
            nameEn = "Library",
            nameKn = "ಗ್ರಂಥಾಲಯ",
            descEn = "2000+ books in Kannada & English",
            descKn = "2000+ ಪುಸ್ತಕಗಳು",
            color = Color(0xFFFFF3E0),
            accent = Color(0xFFF4A300)
        ),
        Facility(
            emoji = "⚽",
            nameEn = "Sports Ground",
            nameKn = "ಕ್ರೀಡಾಂಗಣ",
            descEn = "Football, cricket & kabaddi",
            descKn = "ಫುಟ್ಬಾಲ್, ಕ್ರಿಕೆಟ್ & ಕಬಡ್ಡಿ",
            color = Color(0xFFFFE0E6),
            accent = Color(0xFFC62828)
        ),
        Facility(
            emoji = "🚿",
            nameEn = "Clean Toilets",
            nameKn = "ಶೌಚಾಲಯ",
            descEn = "Separate for boys & girls",
            descKn = "ಹುಡುಗರು & ಹುಡುಗಿಯರಿಗೆ",
            color = Color(0xFFE0F7FA),
            accent = Color(0xFF00838F)
        ),
        Facility(
            emoji = "🖥️",
            nameEn = "Computer Lab",
            nameKn = "ಕಂಪ್ಯೂಟರ್ ಲ್ಯಾಬ್",
            descEn = "30 computers with internet",
            descKn = "ಇಂಟರ್ನೆಟ್ ಸಹಿತ 30 ಕಂಪ್ಯೂಟರ್",
            color = Color(0xFFEDE7F6),
            accent = Color(0xFF6A1B9A)
        )
    )

    var verifiedFacilities by remember { mutableStateOf(setOf<Int>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Header
        Text(
            "🏫 ${strings["facilityTour"] ?: ""}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A2E),
            modifier = Modifier.padding(16.dp, 0.dp, 16.dp, 16.dp)
        )

        // Facility Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            userScrollEnabled = false
        ) {
            items(facilities.size) { index ->
                val facility = facilities[index]
                val isVerified = verifiedFacilities.contains(index)
                val name = if (language == "kn") facility.nameKn else facility.nameEn
                val desc = if (language == "kn") facility.descKn else facility.descEn

                FacilityTile(
                    facility = facility,
                    name = name,
                    description = desc,
                    isVerified = isVerified,
                    verifiedText = strings["verified"] ?: "",
                    onToggle = {
                        verifiedFacilities = if (isVerified) {
                            verifiedFacilities - index
                        } else {
                            verifiedFacilities + index
                        }
                    }
                )
            }
        }

        // Info Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
            border = BorderStroke(1.dp, Color(0xFFBBDEFB))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    "💡 ${strings["tapHint"] ?: ""}",
                    fontSize = 12.sp,
                    color = Color(0xFF0D47A1),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    strings["inspection"] ?: "",
                    fontSize = 11.sp,
                    color = Color(0xFF1565C0)
                )
            }
        }
    }
}

@Composable
fun FacilityTile(
    facility: Facility,
    name: String,
    description: String,
    isVerified: Boolean,
    verifiedText: String,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isVerified) facility.color else Color.White
        ),
        border = BorderStroke(
            2.dp,
            if (isVerified) facility.accent else Color(0xFFEEE)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                facility.emoji,
                fontSize = 36.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFF1A1A2E),
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                description,
                fontSize = 10.sp,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            if (isVerified) {
                Box(
                    modifier = Modifier
                        .background(
                            facility.accent,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .padding(4.dp, 6.dp)
                ) {
                    Text(
                        verifiedText,
                        fontSize = 9.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
